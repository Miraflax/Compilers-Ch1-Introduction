#pragma once

#include "slp.h"

AStm prog(void);
